import Foundation

@objc public class FontosCapacitorBrowser: NSObject {
    @objc public func echo(_ value: String) -> String {
        print(value)
        return value
    }
}
