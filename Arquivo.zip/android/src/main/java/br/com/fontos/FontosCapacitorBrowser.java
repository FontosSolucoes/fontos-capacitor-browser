package br.com.fontos;

import android.util.Log;

public class FontosCapacitorBrowser {

    public String echo(String value) {
        Log.i("Echo", value);
        return value;
    }
}
